import random
import numpy as np
import os
from tqdm import tqdm

from DQN_model import DQN
from football import Football_Env

def sample_list(action_vote):
    total_weight = sum(action_vote)

    probabilities = [x / total_weight for x in action_vote]

    sampled_index = random.choices(range(len(action_vote)), weights=probabilities, k=1)[0]

    return sampled_index


multi_model_action_select_type = 'sample'  # or greedy

max_frames = 50000

sub_num = 1
opp_num = 1
env_name = f'{sub_num}v{opp_num}'
agent_num = sub_num + opp_num
model_j_num = 10
explore_rate = 0.3

sub_path = f'expand_model/{env_name}/'
if not os.path.exists(sub_path):
    os.makedirs(sub_path)

env = Football_Env(sub_num=sub_num, opp_num=opp_num)
sub_obs_size = env.sub_obs_size
opp_obs_size = env.opp_obs_size
sub_action_space = env.sub_action_size
opp_action_space = env.opp_action_size

sub_model = DQN(0, 1, sub_obs_size, sub_action_space, True, max_frames * explore_rate)
opp_model_set = []

for m in range(model_j_num):
    file_head = f'candidate_model/{env_name}/2/'
    opp_model_set.append(DQN(m, 5, opp_obs_size, opp_action_space))
    opp_path = file_head + f'id_{m}.pkl'
    opp_model_set[m].load_model(opp_path)

frame = 0
trial = 0
suc = 0
overdue = 0
total_reward = 0
with tqdm(total=max_frames) as pbar:
    while frame < max_frames:
        obs = env.reset()
        done = False
        truncated = False
        actions = [0] * agent_num
        while not done and not truncated:
            for agt in range(agent_num):
                if agt < sub_num:
                    actions[agt] = (sub_model.choose_action(obs[agt]))[0]
                else:
                    action_vote = [0] * opp_action_space
                    for m in range(model_j_num):
                        a = (opp_model_set[m].choose_action(obs[agt]))[0]
                        action_vote[a] += 1

                    if multi_model_action_select_type == 'sample':
                        actions[agt] = sample_list(action_vote)
                    elif multi_model_action_select_type == 'greedy':
                        actions[agt] = np.argmax(action_vote)

            next_obs, rewards, done, truncated, winner = env.step(actions)
            for agt in range(sub_num):
                    sub_model.store_transition(obs[agt], actions[agt], rewards[agt], next_obs[agt], done)
                    sub_model.update()
                    total_reward += rewards[agt]
                    frame += 1
                    pbar.update(1)
            obs = next_obs
        trial += 1
        if winner == 'attack':
            suc += 1
        elif winner == 'tie':
            overdue += 1
        pbar.set_postfix(
            {'trial': '%d' % trial, 'goal': '%.2f%%' % ((suc / trial) * 100),'overdue': '%.2f%%' % ((overdue / trial) * 100), 'reward': total_reward})

sub_model.save_model(sub_path + f'sub_model_{max_frames}_{model_j_num}.pkl')






