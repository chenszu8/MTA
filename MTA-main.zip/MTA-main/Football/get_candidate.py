import os
import argparse
from tqdm import tqdm

from DQN_model import DQN
from football import Football_Env


class CandidateModel:
    agent_model = []
    agent_type = []
    sub_net = 'DQN'
    opp_net = 'DQN'

    max_frames = 10000
    outset = 0

    def __init__(self, sub_num, opp_num, itera_num, num_candidate, outset):
        self.sub_num = sub_num
        self.opp_num = opp_num
        self.agent_num = sub_num + opp_num
        self.env = Football_Env(sub_num=sub_num, opp_num=opp_num)
        self.sub_obs_size = self.env.sub_obs_size
        self.opp_obs_size = self.env.opp_obs_size
        self.sub_action_space = self.env.sub_action_size
        self.opp_action_space = self.env.opp_action_size
        env_name = f'{sub_num}v{opp_num}'

        self.num_candidate = num_candidate
        self.outset = outset

        dir_path = f'candidate_model/{env_name}/{itera_num}/'
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)

        self.sub_save_path = f'candidate_model/{env_name}/sub_model.pkl'

        if self.sub_net == 'DQN':
            self.agent_model.append(DQN(0, 1, self.sub_obs_size, self.sub_action_space, True, self.max_frames / 2))

        for m in range(self.num_candidate):
            self.model_id = m
            self.agent_model.append(DQN(m + outset, 5, self.opp_obs_size, self.opp_action_space, True, self.max_frames / 2))
            self.opp_save_path = dir_path + f'id_{m + outset}.pkl'
            for i in range(itera_num):
                if i != 0:
                    self.agent_model[1].load_model(self.opp_save_path)

                #self.agent_model[0].buffer.buffer.clear()
                self.train(1)
                self.agent_model[0].load_model(self.sub_save_path)
                #self.agent_model[1].buffer.buffer.clear()
                self.train(2)
            self.agent_model.pop()

    def train(self, train_type):
        if train_type == 1:
            save_path = self.sub_save_path
            a = 0
            b = self.sub_num
        else:
            save_path = self.opp_save_path
            a = self.sub_num
            b = self.agent_num
        trial = 0
        suc = 0
        overdue = 0
        total_reward = 0
        frame = 0
        with tqdm(total=self.max_frames) as pbar:
            while frame < self.max_frames:
                obs = self.env.reset()
                done = False
                truncated = False
                actions = [0] * self.agent_num
                while not done and not truncated:
                    for agt in range(self.agent_num):
                        if agt < self.sub_num:
                            actions[agt] = (self.agent_model[0].choose_action(obs[agt]))[0]
                        else:
                            actions[agt] = (self.agent_model[1].choose_action(obs[agt]))[0]
                    next_obs, rewards, done, truncated, winner = self.env.step(actions)

                    for agt in range(a, b):
                        self.agent_model[train_type - 1].store_transition(obs[agt], actions[agt], rewards[agt], obs[agt], done)
                        self.agent_model[train_type - 1].update()
                        total_reward += rewards[agt]
                        frame += 1
                        pbar.update(1)
                    obs = next_obs
                trial += 1
                if winner == 'attack':
                    suc += 1
                elif winner == 'tie':
                    overdue += 1

                if train_type == 1:
                    pbar.set_postfix(
                        {'trial': '%d' % trial, 'goal': '%.2f%%' % ((suc / trial) * 100), 'reward': total_reward})
                else:
                    pbar.set_postfix(
                        {'trial': '%d' % trial, 'block': '%.2f%%' % ((1 - (suc + overdue) / trial) * 100),
                         'reward': total_reward})
            self.agent_model[train_type - 1].save_model(save_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--num_candidate", default=10, type=int)
    parser.add_argument("--sub_num", default=1, type=int)
    parser.add_argument("--opp_num", default=1, type=int)
    parser.add_argument("--outset", default=0, type=int)
    parser.add_argument("--itera_num", default=2, type=int)
    args = parser.parse_args()
    CandidateModel(args.sub_num, args.opp_num, args.itera_num, args.num_candidate, args.outset)








