import os
from tqdm import tqdm

from football import Football_Env
from DQN_model import DQN

class TrueOppModel:
    agent_model = []
    sub_net = 'DQN'
    opp_net = 'DQN'

    max_frames = 50000

    def __init__(self, sub_num, opp_num, itera_num):
        self.agent_num = sub_num + opp_num
        self.sub_num = sub_num
        self.opp_num = opp_num
        self.env_name = f'{sub_num}v{opp_num}'
        self.env = Football_Env(sub_num=sub_num, opp_num=opp_num)
        self.sub_obs_size = self.env.sub_obs_size
        self.opp_obs_size = self.env.opp_obs_size
        self.sub_action_space = self.env.sub_action_size
        self.opp_action_space = self.env.opp_action_size

        self.itera_num = itera_num

        dir_path = f'single_models/{self.env_name}/{itera_num}/'
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)

        self.sub_save_path = f'single_models/{self.env_name}/{itera_num}/sub_model_term.pkl'
        self.opp_save_path = f'single_models/{self.env_name}/{itera_num}/opp_model_{self.max_frames}.pkl'

        if self.sub_net == 'DQN':
            self.agent_model.append(DQN(0, 1, self.sub_obs_size, self.env.sub_action_size, True, self.max_frames / 2))
        else:
            pass

        if self.opp_net == 'DQN':
            self.agent_model.append(DQN(0, 3, self.opp_obs_size, self.env.opp_action_size, True, self.max_frames / 2))
        else:
            pass

        for i in range(itera_num):
            if i != 0:
                self.agent_model[1].load_model(self.opp_save_path)

            self.agent_model[0].buffer.buffer.clear()
            self.train(1)
            self.agent_model[0].load_model(self.sub_save_path)
            self.agent_model[1].buffer.buffer.clear()
            self.train(2)

    def train(self, train_type):
        if train_type == 1:
            save_path = self.sub_save_path
            a = 0
            b = self.sub_num
        else:
            save_path = self.opp_save_path
            a = self.sub_num
            b = self.agent_num

        trial = 0
        suc = 0
        overdue = 0
        total_reward = 0
        frame = 0
        with tqdm(total=self.max_frames) as pbar:

            while frame < self.max_frames:
                obs = self.env.reset()
                done = False
                truncated = False
                actions = [0] * self.agent_num
                while not done and not truncated:
                    for agt in range(self.agent_num):
                        if agt < self.sub_num:
                            actions[agt] = (self.agent_model[0].choose_action(obs[agt]))[0]
                        else:
                            actions[agt] = (self.agent_model[1].choose_action(obs[agt]))[0]

                    next_obs, rewards, done, truncated, winner = self.env.step(actions)

                    for agt in range(a, b):
                        self.agent_model[train_type - 1].store_transition(obs[agt], actions[agt], rewards[agt], obs[agt], done)
                        self.agent_model[train_type - 1].update()
                        total_reward += rewards[agt]
                        frame += 1
                        pbar.update(1)
                    obs = next_obs
                trial += 1
                if winner == 'attack':
                    suc += 1
                elif winner == 'tie':
                    overdue += 1

                if train_type == 1:
                    pbar.set_postfix(
                        {'trial': '%d' % trial, 'goal': '%.2f%%' % ((suc / trial) * 100), 'reward': total_reward})
                else:
                    pbar.set_postfix(
                        {'trial': '%d' % trial, 'block': '%.2f%%' % ((1 - (suc+overdue) / trial) * 100),
                         'reward': total_reward})
            self.agent_model[train_type - 1].save_model(save_path)


if __name__ == "__main__":
    TrueOppModel(1, 1, 2)







