

import numpy as np
import random
from tqdm import tqdm


from DQN_model import DQN
from football import Football_Env



max_trials = 500
interval = 50

sub_num = 1
opp_num = 1
env_name = f'{sub_num}v{opp_num}'
agent_num = sub_num + opp_num
agents = []

env = Football_Env(sub_num=sub_num, opp_num=opp_num, seed=42)

sub_obs_size = env.sub_obs_size
opp_obs_size = env.opp_obs_size
sub_action_space = env.sub_action_size
opp_action_space = env.opp_action_size

true_opp_path = 'single_models/1v1/2/opp_model_50000.pkl'
expand_sub_path = 'expand_model/1v1/sub_model_50000_10.pkl'

predict_mode = 1
model_num = 0
models = []
belief = []
if predict_mode == 1:
    model_id = []
    head = f'candidate_model/{env_name}/2/'
    if not model_id:
        model_id = [i for i in range(model_num)]
        belief = [1] * model_num
    for i, m in enumerate(model_id):
        path = head + f'id_{m}.pkl'
        models.append(DQN(m, 5, opp_obs_size, opp_action_space))
        models[i].load_model(path)

for i in range(agent_num):
    if i < sub_num:
        agents.append(DQN(i, 1, sub_obs_size, sub_action_space))
        agents[i].load_model(expand_sub_path)
    else:
        agents.append(DQN(i, 3, opp_obs_size, opp_action_space))
        agents[i].load_model(true_opp_path)

success_rate = []
frame = 0
for k in range(int(max_trials / interval)):
    trial = 0
    suc = 0
    loss = 0
    overdue = 0
    sub_total_reward = 0
    opp_total_reward = 0
    with tqdm(total=interval, desc='Iteration %d' % k) as pbar:
        while trial < interval:
            obs = env.reset()
            done = False
            truncated = False
            actions = [0] * agent_num
            while not done and not truncated:

                for agt in range(sub_num, agent_num):
                    actions[agt] = agents[agt].choose_action(obs[agt])[0]
                for agt in range(sub_num):
                    action_list = agents[agt].choose_action(obs[agt])
                    if predict_mode == 1:
                        agent_around = env.who_around(agt)
                        pre_action_list = [-1] * agent_num
                        for other in agent_around:
                            action_weight = [0] * opp_action_space
                            for m in range(model_num):
                                vote = (models[m].choose_action(obs[other]))[0]
                                action_weight[vote] += belief[m]
                                if vote == actions[other]:
                                    belief[m] += 1
                                else:
                                    belief[m] -= 1
                            pre_action_list[other] = np.argmax(action_weight)
                        action_list = [a for a in action_list if env.judge_move(agt, a, pre_action_list)]
                    elif predict_mode == 2:
                        agent_around = env.who_around(agt)
                        pre_action_list = [-1] * agent_num
                        for other in agent_around:
                            pre_action_list[other] = actions[other]
                        action_list = [a for a in action_list if env.judge_move(agt, a, pre_action_list)]

                    if len(action_list) == 0:
                        actions[agt] = random.choice(range(sub_action_space))
                    else:
                        actions[agt] = action_list[0]

                next_obs, rewards, done, truncated, winner = env.step(actions)

                for agt in range(agent_num):
                    agents[agt].store_transition(obs[agt], actions[agt], rewards[agt], next_obs[agt], done)
                    agents[agt].update()
                    if agt < sub_num:
                        sub_total_reward += rewards[agt]
                    else:
                        opp_total_reward += rewards[agt]
                frame += 1
                obs = next_obs
            trial += 1
            if winner == 'attack':
                suc += 1
            elif winner == 'tie':
                overdue += 1
            elif winner == 'pass_block' or winner == 'block':
                loss += 1
            denom = interval
            pbar.set_postfix({'frame': frame, 'trial': '%d' % (trial + interval * k), 'suc': '%.2f%%' % (suc / denom), 'loss': '%.2f%%' % (loss / denom),'overdue': '%.2f%%' % (overdue / denom), 'sub_reward' : sub_total_reward, 'opp_reward':opp_total_reward})
            pbar.update(1)
    success_rate.append(round(suc / interval, 3))
print(success_rate)
