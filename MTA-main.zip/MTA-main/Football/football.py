import time

import numpy as np
import random

from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget
from PyQt5.QtGui import QPainter, QColor, QPen, QBrush, QFont
from PyQt5.QtCore import Qt, QTimer
import sys


class FootballRenderWindow(QMainWindow):
    def __init__(self, env_instance, cell_size=30):
        super().__init__()
        self.env = env_instance
        self.cell_size = cell_size
        self.animation_progress = 0.0

        # 窗口初始化
        self.setWindowTitle("Football Env Visualization")
        self.setGeometry(100, 100,
                         self.env.width * cell_size + 100,
                         self.env.height * cell_size + 100)

        # 定时刷新界面
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_view)
        self.timer.start(50)  # 20 FPS

    def update_view(self):
        """定时刷新界面"""
        if self.env.ball['is_shoot'] and self.animation_progress < 1.0:
            self.animation_progress = min(self.animation_progress + 0.05, 1.0)
        elif not self.env.ball['is_shoot']:
            self.animation_progress = 0.0
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        self.draw_field(painter)
        self.draw_players(painter)
        self.draw_ball(painter)

    def draw_field(self, painter):
        # 绘制绿色场地
        painter.fillRect(50, 50,
                         self.env.width * self.cell_size,
                         self.env.height * self.cell_size,
                         QColor(50, 205, 50))

        # 绘制白色网格线
        painter.setPen(QPen(Qt.white, 1, Qt.DotLine))
        for x in range(self.env.width + 1):
            painter.drawLine(
                50 + x * self.cell_size, 50,
                50 + x * self.cell_size, 50 + self.env.height * self.cell_size
            )
        for y in range(self.env.height + 1):
            painter.drawLine(
                50, 50 + y * self.cell_size,
                    50 + self.env.width * self.cell_size, 50 + y * self.cell_size
            )

        # 绘制球门
        painter.setPen(QPen(Qt.yellow, 3))
        for (x, y) in self.env.gate:
            painter.drawRect(
                50 + y * self.cell_size - 5,
                50 + x * self.cell_size - 5,
                10, 10
            )

    def draw_players(self, painter):
        # 绘制所有球员
        for i, (x, y) in enumerate(self.env.current):
            color = QColor(0, 255, 0) if i < self.env.sub_num else QColor(255, 0, 0)

            # 持球者特殊标记
            if i == self.env.baller:
                painter.setBrush(QColor(255, 255, 0))
                painter.setPen(QPen(Qt.black, 2))
                painter.drawEllipse(
                    50 + y * self.cell_size - 12,
                    50 + x * self.cell_size - 12,
                    24, 24
                )
            if self.env.sub_num <= i <= self.env.agent_num:

                # 计算3x3区域边界
                min_x = max(0, x - 1)
                max_x = min(self.env.height - 1, x + 1)
                min_y = max(0, y - 1)
                max_y = min(self.env.width - 1, y + 1)

                # 绘制有效拦截区域
                for dx in range(min_x, max_x + 1):
                    for dy in range(min_y, max_y + 1):
                        painter.drawRect(
                            50+ dy * self.cell_size - 10,
                            50 + dx * self.cell_size - 10,
                            self.cell_size, self.cell_size
                        )

            # 球员主体
            painter.setBrush(color)
            painter.drawEllipse(
                50 + y * self.cell_size - 10,
                50 + x * self.cell_size - 10,
                20, 20
            )

            # 显示编号
            painter.setPen(Qt.black)
            painter.drawText(
                50 + y * self.cell_size - 5,
                50 + x * self.cell_size + 5,
                str(i)
            )

    def draw_ball(self, painter):
        if self.env.ball['is_shoot']:
            # 计算动画中间位置
            start = self.env.ball['start']
            end = self.env.ball['end']
            current_x = start[0] + (end[0] - start[0]) * self.animation_progress
            current_y = start[1] + (end[1] - start[1]) * self.animation_progress

            # 绘制轨迹线
            painter.setPen(QPen(Qt.blue, 2, Qt.DashLine))
            painter.drawLine(
                50 + start[1] * self.cell_size,
                50 + start[0] * self.cell_size,
                50 + end[1] * self.cell_size,
                50 + end[0] * self.cell_size
            )

            # 绘制运动的球
            painter.setBrush(QColor(255, 255, 0))
            painter.drawEllipse(
                50 + current_y * self.cell_size - 7,
                50 + current_x * self.cell_size - 7,
                14, 14
            )


def merge_array(arr1, arr2):
    combine_list = []
    for row in arr1:
        combine_list.append(row)
    for row in arr2:
        combine_list.append(row)
    return combine_list

def get_neighbors(x, y):
    return [(x + dx, y + dy) for dx in [-1, 0, 1] for dy in [-1, 0, 1]]

def bresenham_line( p1, p2):
    points = []
    dx = abs(p2[0] - p1[0])
    dy = abs(p2[1] - p1[1])
    sx = 1 if p1[0] < p2[0] else -1
    sy = 1 if p1[1] < p2[1] else -1
    err = dx - dy

    x, y = p1
    while True:
        points.append((x, y))
        if x == p2[0] and y == p2[1]:
            break
        e2 = 2 * err
        if e2 > -dy:
            err -= dy
            x += sx
        if e2 < dx:
            err += dx
            y += sy
    return points

class Football_Env:
    def __init__(
            self,
            width = 23,
            height = 20,
            sub_num = 2,
            opp_num = 2,
            view = 30,
            gate_size = 6,
            gamma = 0.99,
            seed = None
    ):
        self.width = width
        self.height = height
        self.sub_num = sub_num
        self.opp_num = opp_num
        self.agent_num = sub_num + opp_num
        self.view = view
        self.gate_size = gate_size
        self.gamma = gamma
        if seed is not None:
            random.seed(seed)

        self.sub_obs_size = (sub_num - 1) * 3 + opp_num * 2 + 2 + 1 + 1
        self.opp_obs_size = sub_num * 3 + opp_num * 2 + 2 + 1
        self.sub_action_size = 5 + gate_size + sub_num - 1
        self.opp_action_size = 5

        self.steps = 0
        self.max_steps = 200
        self.map = None
        self.done = None
        self.path = None
        self.ball = None
        self.winner = None

        self.current = np.zeros((self.agent_num, 2), dtype=int)
        self.pre_current = np.zeros((self.agent_num, 2), dtype=int)
        self.baller = -1
        self.gate = np.zeros((gate_size, 2), dtype=int)
        for i, j in enumerate(range(self.height // 2 - gate_size // 2, self.height // 2 + gate_size // 2 )):
            self.gate[i][0] = j
            self.gate[i][1] = self.width - 1

        self.reset()
    def reset(self, para=None):
        self.steps = 0
        self.done = False
        self.winner = None
        self.map = np.zeros((self.height, self.width), dtype=int)

        self.ball = {'is_shoot': False, 'type': None, 'start':[0, 0], 'end':[0, 0], 'pass_player': None}
        if para is None:
            self.baller = random.randint(0, self.sub_num - 1)
            for agt in range(self.agent_num):
                while True:
                    x = random.randint(0, self.height - 1)
                    if agt < self.sub_num:
                        y = random.randint(0, self.width // 2 - 1)
                    else:
                        y = random.randint(self.width // 2 + 1, self.width - 1)

                    self.current[agt][0] = x
                    self.current[agt][1] = y
                    self.pre_current[agt][0] = x
                    self.pre_current[agt][1] = y
                    if self.map[x][y] == 0:
                        self.map[x][y] = 1 #表示有人即可
                        break
        else:
            self.baller = para['baller']
            for agt in range(self.agent_num):
                self.current[agt][0] = para['current'][agt][0]
                self.current[agt][1] = para['current'][agt][1]
                self.pre_current[agt][0] = self.current[agt][0]
                self.pre_current[agt][1] = self.current[agt][1]

        return self.get_obs()
    def step(self, actions):
        train_reward = np.zeros(self.agent_num)
        self.set_ball(False)
        for i, action in enumerate(actions):
            self.pre_current[i][0] = self.current[i][0]
            self.pre_current[i][1] = self.current[i][1]
            train_reward[i] += self.execute_action(i, action)

        self.steps += 1
        rewards = self.update()
        truncated = self.steps >= self.max_steps
        if truncated:
            for i in range(self.agent_num):
                rewards[i] -= 10
            self.winner = 'tie'

        return self.get_obs(), rewards+train_reward, self.done, truncated, self.winner

    def update(self):
        rewards = np.zeros(self.agent_num)
        if self.ball['is_shoot']:
            opp_pos = []
            for i in range(self.sub_num, self.agent_num):
                opp_pos.append([self.current[i][0], self.current[i][1]])
            outcome = self.intercept_pass(self.ball['start'], self.ball['end'], opp_pos)
            if outcome:
                rewards[self.baller] -= 10
                rewards[outcome] += 200 * self.gamma ** self.steps
                self.winner = 'pass_block'
                self.game_over()
            else:
                if self.ball['type'] == 'shoot':
                    rewards[self.baller] += 200 * self.gamma ** self.steps
                    for i in range(self.sub_num):
                        rewards[i] += 10
                    for i in range(self.sub_num, self.agent_num):
                        rewards[i] -= 10
                    self.winner = 'attack'
                    self.game_over()
                else:
                    self.baller = self.ball['pass_player']
        if not self.done:
            outcome = self.is_block()
            if outcome:
                rewards[self.baller] -= 10
                rewards[outcome] += 200 * self.gamma ** self.steps
                self.winner = 'block'
                self.game_over()

        return rewards


    def execute_action(self, i, action):
        train_rewards = 0
        if action == 0:
            pass
        elif action == 1:
            if self.current[i][0] > 0:
                self.current[i][0] -= 1
            else:
                train_rewards -= 10
        elif action == 2:
            if self.current[i][0] < self.height - 1:
                self.current[i][0] += 1
            else:
                train_rewards -= 10
        elif action == 3:
            if self.current[i][1] > 0:
                self.current[i][1] -= 1
            else:
                train_rewards -= 10
        elif action == 4:
            if self.current[i][1] < self.width - 1:
                self.current[i][1] += 1
                train_rewards += 0
            else:
                train_rewards -= 10
        elif self.baller == i:
            if action - 5 < self.sub_num - 1:
                mate = action - 5
                if mate >= i:
                    mate += 1
                res_x = self.pre_current[i][0] - self.pre_current[mate][0]
                res_y = self.pre_current[i][1] - self.pre_current[mate][1]
                if abs(res_x) <= self.view and abs(res_y) <= self.view:
                    self.set_ball(True, self.pre_current[i], self.pre_current[mate], 'pass', mate)
                else:
                    train_rewards -= 10
            else:
                if self.pre_current[i][1] >= 0.65 * self.width:
                    self.set_ball(True, self.pre_current[i], self.gate[action - 4 - self.sub_num], 'shoot')
                else:
                    train_rewards -= 10
        return train_rewards

    def get_obs(self):
        sub_obs = np.zeros((self.sub_num, self.sub_obs_size))
        opp_obs = np.zeros((self.opp_num, self.opp_obs_size))

        for agt in range(self.sub_num):

            onset = 0
            for i in range(self.sub_num):
                if i == agt:
                    continue
                res_x = self.current[agt][0] - self.current[i][0]
                res_y = self.current[agt][1] - self.current[i][1]
                is_baller = int(self.baller == i) + 1
                if abs(res_x) > self.view or abs(res_y) > self.view:
                    res_x = self.view + 1
                    res_y = self.view + 1
                    is_baller = 0
                sub_obs[agt][onset] = res_x
                sub_obs[agt][onset + 1] = res_y
                sub_obs[agt][onset + 2] = is_baller
                onset += 3

            for i in range(self.sub_num, self.agent_num):
                res_x = self.current[agt][0] - self.current[i][0]
                res_y = self.current[agt][1] - self.current[i][1]
                if abs(res_x) > self.view or abs(res_y) > self.view:
                    res_x = self.view + 1
                    res_y = self.view + 1
                sub_obs[agt][onset] = res_x
                sub_obs[agt][onset + 1] = res_y
                onset += 2

            res_x = self.current[agt][0] - self.gate[0][0]
            res_y = self.current[agt][1] - self.gate[0][1]
            sub_obs[agt][onset] = res_x
            sub_obs[agt][onset + 1] = res_y
            sub_obs[agt][onset + 2] = int(self.baller == agt) + 1
            sub_obs[agt][onset + 3] = self.steps
            onset += 4
            assert  onset == self.sub_obs_size

        for agt in range(self.opp_num):
            id_in_all = agt + self.sub_num
            onset = 0
            for i in range(self.sub_num, self.agent_num):
                if i == agt:
                    continue
                res_x = self.current[id_in_all][0] - self.current[i][0]
                res_y = self.current[id_in_all][1] - self.current[i][1]
                if abs(res_x) > self.view or abs(res_y) > self.view:
                    res_x = self.view + 1
                    res_y = self.view + 1
                opp_obs[agt][onset] = res_x
                opp_obs[agt][onset + 1] = res_y
                onset += 2

            for i in range(self.sub_num):
                res_x = self.current[id_in_all][0] - self.current[i][0]
                res_y = self.current[id_in_all][1] - self.current[i][1]
                is_baller = int(self.baller == i) + 1
                if abs(res_x) > self.view or abs(res_y) > self.view:
                    res_x = self.view + 1
                    res_y = self.view + 1
                    is_baller = 0
                opp_obs[agt][onset] = res_x
                opp_obs[agt][onset + 1] = res_y
                opp_obs[agt][onset + 2] = is_baller
                onset += 3

            res_x = self.current[id_in_all][0] - self.gate[0][0]
            res_y = self.current[id_in_all][1] - self.gate[0][1]
            opp_obs[agt][onset] = res_x
            opp_obs[agt][onset + 1] = res_y
            opp_obs[agt][onset + 2] = self.steps
            onset += 3
            assert onset == self.opp_obs_size

        return merge_array(sub_obs, opp_obs)

    def set_ball(self, shoot, start=None, end=None, type=None, player=None):
        if shoot:
            self.ball['is_shoot'] = True
            self.ball['start'][0] = start[0]
            self.ball['start'][1] = start[1]
            self.ball['end'][0] = end[0]
            self.ball['end'][1] = end[1]
            self.ball['type'] = type
            self.ball['pass_player'] = player
        else:
            self.ball['is_shoot'] = False

    def intercept_pass(self, start, end, defenders):

        def is_between(p, q, r):
            return min(p[0], r[0]) <= q[0] <= max(p[0], r[0]) and \
                   min(p[1], r[1]) <= q[1] <= max(p[1], r[1])


        path_points = bresenham_line(start, end)

        valid_defenders = [(idx, pos) for idx, pos in enumerate(defenders)
                           if is_between(start, pos, end)]

        for point in path_points:
            for idx, pos in valid_defenders:
                if point in get_neighbors(*pos):
                    return idx + self.sub_num
        return False

    def game_over(self):
        self.done = True

    def is_block(self):
        baller_pos = self.current[self.baller]
        baller_x, baller_y = baller_pos

        baller_neighbors = set(get_neighbors(baller_x, baller_y))
        for i in range(self.sub_num, self.agent_num):
            agent_pos = self.current[i]
            agent_x, agent_y = agent_pos
            if (agent_x, agent_y) in baller_neighbors:
                return i

        return False
    def who_around(self, agt):
        around = []
        for i in range(self.sub_num, self.agent_num):
            res_x = self.current[i][0] - self.current[agt][0]
            res_y = self.current[i][1] - self.current[agt][1]
            if abs(res_x) < self.view and abs(res_y) < self.view:
                around.append(i)
        return around

    def judge_move(self, agt, a, a_list):

        self.set_ball(False)
        if self.baller != agt:
            return True
        x, y = self.virtual_move(agt, a)
        opp_pos = []
        for i in range(self.sub_num, self.agent_num):
            if a_list[i] != -1:
                opp_x, opp_y = self.virtual_move(i, a_list[i])
                opp_pos.append([opp_x, opp_y])
        agt_neighbor = get_neighbors(x, y)
        for i, j in opp_pos:
            if (i, j) in agt_neighbor:
                return False
        if a - 5 < self.sub_num - 1 and a > 4:
            mate = a - 5
            if mate >= agt:
                mate += 1
            res_x = self.pre_current[agt][0] - self.pre_current[mate][0]
            res_y = self.pre_current[agt][1] - self.pre_current[mate][1]
            if abs(res_x) <= self.view and abs(res_y) <= self.view:
                self.set_ball(True, self.pre_current[agt], self.pre_current[mate], 'pass', mate)
            else:
                return True
        else:
            if self.pre_current[agt][1] >= 0.65 * self.width:
                self.set_ball(True, self.pre_current[agt], self.gate[agt - 4 - self.sub_num], 'shoot')
        outcome = self.intercept_pass(self.ball['start'], self.ball['end'], opp_pos)
        if outcome:
            return False
        else:
            return True

    def virtual_move(self, agt, action):
        x = self.current[agt][0]
        y = self.current[agt][1]
        if action == 1:
            if x > 0:
                x -= 1
        elif action == 2:
            if x < self.height - 1:
                x += 1
        elif action == 3:
            if y > 0:
                y -= 1
        elif action == 4:
            if y < self.width - 1:
                y += 1
        return x, y

if __name__ == "__main__":
    # 初始化环境和渲染窗口
    env = Football_Env(width=23, height=20)
    app = QApplication(sys.argv)
    window = FootballRenderWindow(env)
    window.show()

    # 模拟运行
    for _ in range(100):
        # 随机动作
        actions = [0] * env.agent_num
        for i in range(env.sub_num):
            actions[i] = random.randint(0,env.sub_action_size - 1)
        for i in range(env.sub_num, env.agent_num):
            actions[i] = random.randint(0,env.opp_action_size - 1)

        # 执行环境步骤
        env.step(actions)

        # 控制更新速度
        time.sleep(0.1)
        app.processEvents()  # 处理GUI事件

    sys.exit(app.exec_())



#dongzuo 的排除







