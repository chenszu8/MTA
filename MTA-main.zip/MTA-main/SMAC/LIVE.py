import numpy as np
import os
import random
from tqdm import tqdm
import time
import gymnasium as gym
import smaclite

from sysj import save_results_to_json
from DQN_model import DQN
from VDN_model import VDN
from COMA_model import COMA
from QMIX_model import QMIX

USE_CPP_RVO2 = False
RENDER = False
sub_net = 'VDN'
opp_net = 'DQN'
def normalize_list(data):
    if not data:
        return []

    min_val = min(data)
    shifted = [x - min_val for x in data]
    total = sum(shifted)

    if total == 0:
        length = len(data)
        return [1 / length] * length

    normalized = [x / total for x in shifted]
    return normalized

max_trials = 500
interval = 50
predict_mode = 0

#MTA
predict_num = 50
model_list = [62,75,59,81,17,33,77,16,47,88]

env_name = "3m_vs_3m"
env = gym.make(f"smaclite/{env_name}-v0", use_cpp_rvo2=USE_CPP_RVO2)
sub_agents = []
opp_agents = []

sub_path = './expand_model/1v1/sub_model_30000.pkl'
opp_path = f'/home/chenfanke/aamas_2025/smac_re/smaclite-master/single_model/3m_vs_3m/sub_model_1_term.pkl'

sub_num = env.unwrapped.n_agents
opp_num = env.unwrapped.n_enemies
agent_num = sub_num + opp_num

num_state_sub = env.unwrapped.obs_size
num_state_opp = env.unwrapped.opp_obs_size
num_actions_sub = env.unwrapped.n_actions
num_actions_opp = env.unwrapped.opp_n_actions
if sub_net == 'VDN':
    sub_agents = VDN(num_state_sub, num_actions_sub, sub_num)
elif sub_net == 'COMA':
    sub_agents = COMA(sub_num, num_state_sub, num_actions_sub)
elif sub_net == 'QMIX':
    sub_agents = QMIX(sub_num, num_state_sub, num_actions_sub)

elif sub_net == 'DQN':
    for i in range(sub_num):
        sub_agents.append(DQN(i, 1, num_state_sub, num_actions_sub))
        if sub_path:
            sub_agents[i].load_model(sub_path)

for i in range(opp_num):
    opp_agents.append(DQN(i, 1, num_state_opp, num_actions_opp))
    opp_agents[i].load_model(opp_path)

if predict_mode == 1:
    predict_model = []
    head = f'candidate_model/{env_name}/'
    for m in range(predict_num):
    #for i, m in enumerate(model_list):
        path = head + f'id_{m}.pkl'
        predict_model.append(DQN(m, 5, num_state_opp, num_actions_opp))
        predict_model[m].load_model(path)

    predict_belief = [1] * predict_num
s_time = time.time()

success_rate = []

for k in range(int(max_trials / interval)):
    trial = 0
    suc = 0
    loss = 0
    overdue = 0

    with tqdm(total=interval, desc='Iteration %d' % k) as pbar:
        total_reward = 0
        while trial < interval:
            obs, _ = env.reset()
            sub_obs = obs[0]
            opp_obs = obs[1]
            done = False
            truncated = False
            while not done and not truncated:
                sub_actions = [] 
                opp_actions = [] 
                last_sub = []
                last_opp = []
                sub_avail_actions = env.unwrapped.get_avail_actions()
                opp_avail_actions = env.unwrapped.opp_get_avail_actions()
                for i in range(env.unwrapped.n_enemies):
                    if i in env.unwrapped.enemies:
                        action = opp_agents[i].choose_action(opp_obs[i])
                        last_opp.append(i)
                    else:
                        opp_actions.append(0)
                        continue
                    avail_indices = [int(a) for a, valid in enumerate(opp_avail_actions[i]) if valid]
                    action = [x for x in action if x in avail_indices]
                    if len(action) > 0:
                        opp_actions.append(action[0])
                    else:
                        opp_actions.append(int(np.random.choice(avail_indices)))
                if sub_net == 'VDN':
                    actions = sub_agents.choose_action(sub_obs)
                    for i in range(env.unwrapped.n_agents):
                        if i in env.unwrapped.agents:
                            last_sub.append(i)
                        else:
                            sub_actions.append(0)
                            continue
                        agt_avail_indices = [int(a) for a, valid in enumerate(sub_avail_actions[i]) if valid]
                        action = [x for x in actions[i] if x in agt_avail_indices]
                        if len(action):
                            sub_actions.append(action[0])
                        else:
                            sub_actions.append(int(np.random.choice(agt_avail_indices)))
                elif sub_net == 'COMA' or sub_net == 'QMIX':
                    sub_actions = sub_agents.choose_action(sub_obs, sub_avail_actions)


                next_obs, reward, dones, done, truncated, info = env.step([sub_actions, opp_actions])
                
                next_sub_obs = next_obs[0]
                next_opp_obs = next_obs[1]
                sub_reward = reward[0]
                opp_reward = reward[1]
                sub_dones = dones[0]
                opp_dones = dones[1]
                if sub_net == 'QMIX' or sub_net == 'COMA':
                    sub_agents.store_transition(sub_obs, sub_actions, sub_reward, next_sub_obs, sub_dones, sub_avail_actions)
                else:
                    sub_agents.store_transition(sub_obs, sub_actions, sub_reward, next_sub_obs, sub_dones)
                sub_agents.update()
                total_reward += sum(sub_reward)
                sub_obs = next_sub_obs
                opp_obs = next_opp_obs
            trial += 1
            sub_info = info[0]["battle_won"]
            opp_info = info[1]["battle_won"]

            if sub_info and opp_info:
                print('error')
                exit(0)
            elif sub_info:
                suc += 1
            elif opp_info:
                loss += 1
            elif not sub_info and not opp_info:
                overdue += 1
            denom = interval
            pbar.set_postfix({'trial': '%d' % (trial + interval * k), 'suc': '%.2f%%' % (suc / denom), 'overdue': '%.2f%%' % (overdue / denom), 'loss': '%.2f%%' % (loss / denom),
                              'avg_sub_reward': total_reward / trial})
            pbar.update(1)

    success_rate.append(round(suc / (interval * sub_num), 3))
e_time = time.time()
mode = 'VDN'
opp_type = 'regular'
datas = {
    f'consume_time_{mode}_{opp_type}':e_time - s_time,
    f'success_rate_{mode}_{opp_type}':success_rate,
}
save_log_path = './log/'
if not os.path.exists(save_log_path):
    os.makedirs(save_log_path)
json_save_path = save_log_path + 'online.json'
json_lock_path = json_save_path + '.lock'
save_results_to_json(datas, json_save_path, json_lock_path)





