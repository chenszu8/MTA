import numpy as np
import os
import time
import argparse
import pickle
import random
import multiprocessing
from tqdm import tqdm
from DQN_model import DQN
import time
import gymnasium as gym
import smaclite

USE_CPP_RVO2 = False

env_name = "3m_vs_3m"
class TrueOppModel:
    agent_model = []
    sub_net = 'DQN'
    opp_net = 'DQN'
    
    env = gym.make(f"smaclite/{env_name}-v0", use_cpp_rvo2=USE_CPP_RVO2)
    num_sub = env.unwrapped.n_agents
    num_opp = env.unwrapped.n_enemies
    num_state_sub = env.unwrapped.obs_size
    num_state_opp = env.unwrapped.opp_obs_size
    num_actions_sub = env.unwrapped.n_actions
    num_actions_opp = env.unwrapped.opp_n_actions
    max_frames = 30000


    def __init__(self, itera_num):

        dir_path = f'single_model/{env_name}/{itera_num}/'
        if not os.path.exists(dir_path):
                os.makedirs(dir_path)
                print("have created directory", dir_path)

        self.sub_save_path = f'single_model/{env_name}/sub_model_{itera_num}_term.pkl'
        self.opp_save_path = f'single_model/{env_name}/opp_model_{itera_num}_{self.max_frames}_next.pkl'
        
        if self.sub_net == 'DQN':
            self.agent_model.append(DQN(0, 1, self.num_state_sub, self.num_actions_sub))
        else:
            pass

        if self.opp_net == 'DQN':
            self.agent_model.append(DQN(0, 1, self.num_state_opp, self.num_actions_opp, True, self.max_frames * 0.6))
        else:
            pass

        for i in range(itera_num):
            # if i != 0:
            self.agent_model[1].load_model('single_model/3m_vs_3m/opp_model_1_30000.pkl')

            # self.agent_model[0].buffer.buffer.clear()
            # self.agent_model[0].set_learn_flag()
            # self.train(1)
            self.agent_model[0].load_model(self.sub_save_path)
            #self.agent_model[1].buffer.buffer.clear()
            #self.agent_model[1].set_learn_flag()
            self.train(2)

    def train(self, train_type):
        if train_type == 1:
            save_path = self.sub_save_path
        else:
            save_path = self.opp_save_path

        frame = 0
        trial = 0
        suc = 0
        overdue = 0
        total_reward = 0
        frame = 0
        loss = 0
        with tqdm(total=self.max_frames) as pbar:
            while frame < self.max_frames:
                obs, _ = self.env.reset()
                done = False
                truncated = False
                sub_obs = obs[0]
                opp_obs = obs[1]
                while not truncated and not done:
                    sub_actions = [] 
                    opp_actions = []
                    last_sub = []
                    last_opp = []

                    sub_avail_actions = self.env.unwrapped.get_avail_actions()
                    opp_avail_actions = self.env.unwrapped.opp_get_avail_actions()

                    for i in range(self.env.unwrapped.n_agents):
                        if i in self.env.unwrapped.agents:
                            action = self.agent_model[0].choose_action(sub_obs[i])
                            last_sub.append(i)
                        else:
                            sub_actions.append(0)
                            continue

                        avail_indices = [int(a) for a, valid in enumerate(sub_avail_actions[i]) if valid]
                        action = [x for x in action if x in avail_indices]
                        if len(action) > 0:
                            sub_actions.append(action[0])
                        else:
                            sub_actions.append(int(np.random.choice(avail_indices)))

                    for i in range(self.env.unwrapped.n_enemies):
                        if i in self.env.unwrapped.enemies:
                            action = self.agent_model[1].choose_action(opp_obs[i])
                            last_opp.append(i)
                        else:
                            opp_actions.append(0)
                            continue

                        avail_indices = [int(a) for a, valid in enumerate(opp_avail_actions[i]) if valid]

                        action = [x for x in action if x in avail_indices]
                        if len(action) > 0:
                            opp_actions.append(action[0])
                        else:
                            opp_actions.append(int(np.random.choice(avail_indices)))

                    next_obs, reward, dones, done, truncated, info = self.env.step([sub_actions, opp_actions])
                    next_sub_obs = next_obs[0]
                    next_opp_obs = next_obs[1]
                    sub_reward = reward[0]
                    opp_reward = reward[1]
                    sub_dones = dones[0]
                    opp_dones = dones[1]

                    if train_type == 1:
                        for agt in last_sub:
                            self.agent_model[0].store_transition(sub_obs[agt], sub_actions[agt], sub_reward[agt], next_sub_obs[agt], sub_dones[agt])
                            self.agent_model[0].update() 
                            frame += 1
                            pbar.update(1)
                        total_reward += sum(sub_reward)
                    else:
                        for agt in last_opp:
                            self.agent_model[1].store_transition(opp_obs[agt], opp_actions[agt], opp_reward[agt], next_opp_obs[agt], opp_dones[agt])
                            self.agent_model[1].update() 
                            frame += 1
                            pbar.update(1)
                        total_reward += sum(opp_reward)

                    sub_obs = next_sub_obs
                    opp_obs = next_opp_obs

                trial += 1
                sub_info = info[0]["battle_won"]
                opp_info = info[1]["battle_won"]

                if sub_info and opp_info:
                    print('error')
                    exit(0)
                elif sub_info:
                    suc += 1
                elif opp_info:
                    loss += 1
                elif not sub_info and not opp_info:
                    overdue += 1
                if train_type == 1:
                    pbar.set_postfix({'trial' : '%d' % trial, 'suc': '%.2f%%' % (suc/trial),'overdue':'%.2f%%' % (overdue/trial), 'loss':'%.2f%%' % (loss/trial),  'reward': total_reward/trial})
                else:
                    pbar.set_postfix({'trial': '%d' % trial, 'loss': '%.2f%%' % (loss/trial),'overdue':'%.2f%%' % (overdue/trial), 'suc': '%.2f%%' % (suc/trial), 'reward': total_reward/trial, 'loss_num' : loss}) 

        self.agent_model[train_type - 1].save_model(save_path)
if __name__ == "__main__":
    TrueOppModel(1)


                        

    
        

