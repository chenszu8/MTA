import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
from collections import deque
import random

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class Actor(nn.Module):
    def __init__(self, obs_dim, action_dim):
        super(Actor, self).__init__()
        self.fc1 = nn.Linear(obs_dim, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, action_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)

class Critic(nn.Module):
    def __init__(self, n_agents, obs_dim, action_dim):
        super(Critic, self).__init__()
        self.n_agents = n_agents
        input_dim = n_agents * obs_dim + n_agents * action_dim
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, 1)

    def forward(self, state, actions):
        x = torch.cat([state, actions], dim=1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)

class ReplayBuffer:
    def __init__(self, capacity, n_agents, obs_dim, action_dim):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)
        self.n_agents = n_agents
        self.obs_dim = obs_dim
        self.action_dim = action_dim

    def add(self, obs, actions, rewards, next_obs, dones, avail_actions):
        self.buffer.append((
            np.array(obs, dtype=np.float32),
            np.array(actions, dtype=np.int64),
            np.array(rewards, dtype=np.float32),
            np.array(next_obs, dtype=np.float32),
            np.array(dones, dtype=np.float32),
            np.array(avail_actions, dtype=np.int64)
        ))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        obs, actions, rewards, next_obs, dones, avail_actions = zip(*batch)
        return (
            torch.tensor(np.array(obs), dtype=torch.float32).to(device),
            torch.tensor(np.array(actions), dtype=torch.long).to(device),
            torch.tensor(np.array(rewards), dtype=torch.float32).to(device),
            torch.tensor(np.array(next_obs), dtype=torch.float32).to(device),
            torch.tensor(np.array(dones), dtype=torch.float32).to(device),
            torch.tensor(np.array(avail_actions), dtype=torch.float32).to(device)
        )

    def __len__(self):
        return len(self.buffer)

class COMA:
    epsilon = 1.0    
    eps_end = 0.05
    eps_decay = 0.995
    def __init__(self, n_agents, obs_dim, action_dim, lr_actor=1e-5, lr_critic=1e-4, 
                 gamma=0.99, buffer_size=4000, batch_size=64):
        self.n_agents = n_agents
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.batch_size = batch_size

        # Actor网络共享参数
        self.actor = Actor(obs_dim, action_dim).to(device)
        self.actor_optim = optim.Adam(self.actor.parameters(), lr=lr_actor)

        # Critic网络
        self.critic = Critic(n_agents, obs_dim, action_dim).to(device)
        self.critic_optim = optim.Adam(self.critic.parameters(), lr=lr_critic)

        # 经验回放池
        self.buffer = ReplayBuffer(buffer_size, n_agents, obs_dim, action_dim)

    def choose_action(self, obs, avail_actions):
        """
        改进后的动作选择方法
        :param epsilon: 可手动指定ε值（用于测试时设为0）
        """
        actions = []
        
        for agent_idx in range(self.n_agents):
            # ε-greedy探索
            if random.random() < self.epsilon:
                # 随机选择可用动作
                avail = np.where(avail_actions[agent_idx])[0]
                if len(avail) == 0:  # 防止无可用动作
                    action = 0
                else:
                    action = int(np.random.choice(avail))
            else:
                # 基于策略网络选择动作
                obs_tensor = torch.FloatTensor(obs[agent_idx]).to(device)
                with torch.no_grad():
                    logits = self.actor(obs_tensor)
                
                # 应用动作掩码
                mask = torch.BoolTensor(avail_actions[agent_idx]).to(device)
                logits[~mask] = -float('inf')
                
                dist = torch.distributions.Categorical(logits=logits)
                action = dist.sample().item()
            actions.append(action)
        self.update_epsilon()
        return actions

    def update(self):
        if len(self.buffer) < self.batch_size:
            return

        # 从buffer中采样
        obs, actions, rewards, next_obs, dones, avail_actions = self.buffer.sample(self.batch_size)
        batch_size = obs.size(0)

        # 转换为Critic需要的格式
        state = obs.view(batch_size, -1)  # [batch, n_agents*obs_dim]
        actions_oh = F.one_hot(actions, num_classes=self.action_dim).view(batch_size, -1)  # [batch, n_agents*action_dim]

        # 计算当前Q值
        current_q = self.critic(state, actions_oh).squeeze(-1)  # [batch]

        # 计算target Q值
        with torch.no_grad():
            # 计算target actions
            target_actions = []
            for b in range(batch_size):
                batch_actions = []
                for agent_idx in range(self.n_agents):
                    obs_tensor = next_obs[b, agent_idx]
                    logits = self.actor(obs_tensor)
                    
                    mask = avail_actions[b, agent_idx].bool()
                    logits[~mask] = -float('inf')
                    
                    dist = torch.distributions.Categorical(logits=logits)
                    action = dist.sample()
                    batch_actions.append(action.item())
                target_actions.append(batch_actions)
            target_actions = torch.tensor(target_actions, device=device)
            target_actions_oh = F.one_hot(target_actions, num_classes=self.action_dim).view(batch_size, -1)
            
            next_state = next_obs.view(batch_size, -1)
            target_q = rewards.sum(dim=1) + self.gamma * (1 - dones[:,0]) * self.critic(next_state, target_actions_oh).squeeze()

        # 更新Critic
        critic_loss = F.mse_loss(current_q, target_q)
        self.critic_optim.zero_grad()
        critic_loss.backward()
        self.critic_optim.step()

        # 更新Actor
        actor_loss = 0
        for agent_idx in range(self.n_agents):
            agent_obs = obs[:, agent_idx, :]  # [batch, obs_dim]
            agent_actions = actions[:, agent_idx]  # [batch]
            
            logits = self.actor(agent_obs)  # [batch, action_dim]
            mask = avail_actions[:, agent_idx].bool()  # [batch, action_dim]
            logits[~mask] = -float('inf')
            
            log_probs = F.log_softmax(logits, dim=-1)
            selected_log_probs = log_probs.gather(1, agent_actions.unsqueeze(1))  # [batch, 1]
            
            # 计算优势函数
            with torch.no_grad():
                baseline = self.critic(state, actions_oh).squeeze()
            
            actor_loss += (-selected_log_probs.squeeze() * baseline.detach()).mean()

        actor_loss /= self.n_agents
        self.actor_optim.zero_grad()
        actor_loss.backward()
        self.actor_optim.step()

    def store_transition(self, obs, actions, rewards, next_obs, dones, avail_actions):
        self.buffer.add(obs, actions, rewards, next_obs, dones, avail_actions)
    
    def update_epsilon(self):
        """ 衰减ε值 """
        self.epsilon = max(self.eps_end, self.epsilon * self.eps_decay)