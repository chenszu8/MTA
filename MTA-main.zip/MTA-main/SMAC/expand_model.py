import random
import numpy as np
import os
import smaclite
import gymnasium as gym
from tqdm import tqdm

from DQN_model import DQN


def sample_list(action_vote):

    total_weight = sum(action_vote)

    probabilities = [x / total_weight for x in action_vote]

    sampled_index = random.choices(range(len(action_vote)), weights=probabilities, k=1)[0]

    return sampled_index

USE_CPP_RVO2 = False
multi_model_action_select_type = 'sample' #or greedy

max_frames = 50000

model_j_num = 100
explore_rate = 0.6
env_name = "3m_vs_3m"
env = gym.make(f"smaclite/{env_name}-v0", use_cpp_rvo2= USE_CPP_RVO2)
num_sub = env.unwrapped.n_agents
num_opp = env.unwrapped.n_enemies

num_actions_sub = env.unwrapped.n_actions
num_actions_opp = env.unwrapped.opp_n_actions

num_state_sub = env.unwrapped.obs_size
num_state_opp = env.unwrapped.opp_obs_size 

num_actions_sub = env.unwrapped.n_actions
num_actions_opp = env.unwrapped.opp_n_actions


sub_path = f'expand_model/{env_name}/{model_j_num}/'
if not os.path.exists(sub_path):
    os.makedirs(sub_path)


sub_model = DQN(0, 1, num_state_sub, num_actions_sub, True, max_frames * explore_rate)
opp_model_set = []

for m in range(model_j_num):
    file_head = f'candidate_model/{env_name}/'
    opp_model_set.append(DQN(m, 5, num_state_opp, num_actions_opp))
    opp_path = file_head + f'id_{m}.pkl' 
    opp_model_set[m].load_model(opp_path)

frame = 0
trial = 0
suc = 0
overdue = 0
loss = 0
total_reward = 0
with tqdm(total=max_frames) as pbar:

    while frame < max_frames:
        obs, _ = env.reset()
        done = False
        truncated = False
        sub_obs = obs[0]
        opp_obs = obs[1]
        
        while not truncated and not done:

            sub_actions = [] 
            opp_actions = []
            last_sub = []
            last_opp = []

            sub_avail_actions = env.unwrapped.get_avail_actions()
            opp_avail_actions = env.unwrapped.opp_get_avail_actions()

            for i in range(env.unwrapped.n_enemies):
                if i in env.unwrapped.enemies:
                    last_opp.append(i)
                else:
                    opp_actions.append(0)
                    continue

                action_vote = [0] * num_actions_opp
                avail_indices = [int(a) for a, valid in enumerate(opp_avail_actions[i]) if valid]

                for m in range(model_j_num):
                    a = opp_model_set[m].choose_action(opp_obs[i])
                    while a[0] not in avail_indices:
                        a.pop(0)
                    if len(a) > 0:
                        action_vote[a[0]] += 1
                if multi_model_action_select_type == 'sample':
                    opp_actions.append(sample_list(action_vote))
                elif multi_model_action_select_type == 'greedy':
                    opp_actions.append(np.argmax(action_vote))

            for i in range(env.unwrapped.n_agents):
                if i in env.unwrapped.agents:
                    action = sub_model.choose_action(sub_obs[i])
                    last_sub.append(i)
                else:
                    sub_actions.append(0)
                    continue

                avail_indices = [int(a) for a, valid in enumerate(sub_avail_actions[i]) if valid]
                while action[0] not in avail_indices:
                    action.pop(0)
                if len(action) > 0:
                    sub_actions.append(action[0])
                else:
                    sub_actions.append(int(np.random.choice(avail_indices)))

            next_obs, reward, dones, done, truncated, info = env.step([sub_actions, opp_actions])
            next_sub_obs = next_obs[0]
            next_opp_obs = next_obs[1]
            sub_reward = reward[0]
            opp_reward = reward[1]
            sub_dones = dones[0]
            opp_dones = dones[1]

            for agt in last_sub:
                sub_model.store_transition(sub_obs[agt], sub_actions[agt], sub_reward[agt], next_sub_obs[agt], sub_dones[agt])
                sub_model.update() 
                frame += 1
                pbar.update(1)
            total_reward += sum(sub_reward)
            sub_obs = next_sub_obs
            opp_obs = next_opp_obs
        trial += 1
        sub_info = info[0]["battle_won"]
        opp_info = info[1]["battle_won"]
        if sub_info and opp_info:
            print('error')
            exit(0)
        elif sub_info:
            suc += 1
        elif opp_info:
            loss += 1
        elif not sub_info and not opp_info:
            overdue += 1
        pbar.set_postfix(
            {'trial': '%d' % trial, 'suc': '%.2f%%' % ((suc / trial) * 100),'overdue': '%.2f%%' % ((overdue / trial) * 100),'loss': '%.2f%%' % ((loss / trial) * 100),  'reward': total_reward})


sub_model.save_model(sub_path + f'sub_model_{max_frames}_{explore_rate}.pkl')
    


