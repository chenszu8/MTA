from Net_type import Net1, Net2, Net3, CandidateModel
import torch
import torch.nn as nn
import numpy as np
import random
import collections

device = torch.device("cuda")

class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = collections.deque(maxlen=capacity)
    
    def add(self, obs, actions, rewards, next_obs, done):
        self.buffer.append((obs, actions, rewards, next_obs, done))
    
    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        n_agents = len(batch[0][0])
        
        transposed = list(zip(*batch))
        obs_batch = np.array(transposed[0])
        actions_batch = np.array(transposed[1])
        rewards_batch = np.array(transposed[2])
        next_obs_batch = np.array(transposed[3])
        dones_batch = np.array(transposed[4])
        
        return {
            'obs': [obs_batch[:, i] for i in range(n_agents)],
            'actions': [actions_batch[:, i] for i in range(n_agents)],
            'rewards': rewards_batch.mean(axis=1),  # 假设使用团队奖励
            'next_obs': [next_obs_batch[:, i] for i in range(n_agents)],
            'dones': dones_batch
        }
    def __len__(self):
        return len(self.buffer)
    
class VDN:
    batch_size = 32
    lr = 1e-5
    gamma = 0.99

    buffer_size = 10000
    minimal_size = 500
    target_update = 50
    count = 0

    epsilon_start = 1
    epsilon_time = 10000
    epsilon_end = 0.05
    tau = 0.05
    
    def __init__(self, num_input, num_output, n_agents, learn_flag = False, epsilon_time = 15000):
        self.epsilon_time = epsilon_time
        self.set_learn_flag(learn_flag)
        self.num_actions = num_output
        self.n_agents = n_agents
        self.buffer = ReplayBuffer(self.buffer_size)
        self.eval_net =  [Net1(num_input, num_output).to(device) for _ in range(n_agents)]
        self.target_net = [Net1(num_input, num_output).to(device) for _ in range(n_agents)]
        for net, target_net in zip(self.eval_net, self.target_net): 
            target_net.load_state_dict(net.state_dict())
        self.optimizers = [torch.optim.Adam(net.parameters(), lr=self.lr) for net in self.eval_net]
    
    def choose_action(self, obs, deterministic=False):
        actions_list = []
        if self.epsilon > self.epsilon_end:
            self.epsilon -= (self.epsilon - self.epsilon_end) / self.epsilon_time
        for i, ob in enumerate(obs):
            if np.random.random() < self.epsilon and not deterministic:
                actions = [i for i in range(self.num_actions)]
                random.shuffle(actions)
            else:
                action_value = self.eval_net[i](torch.FloatTensor(ob).to(device))
                _, index = action_value.sort(descending = True)
                actions = index.tolist()

            actions_list.append(actions)
        return actions_list
    
    def update(self):
        if len(self.buffer) < self.minimal_size:
            return 
        batch = self.buffer.sample(self.batch_size)
        obs = [torch.FloatTensor(batch['obs'][i]).to(device) for i in range(self.n_agents)]
        actions = [torch.LongTensor(batch['actions'][i]).to(device) for i in range(self.n_agents)]
        rewards = torch.FloatTensor(batch['rewards']).to(device)
        next_obs = [torch.FloatTensor(batch['next_obs'][i]).to(device) for i in range(self.n_agents)]
        dones = torch.FloatTensor(batch['dones']).to(device)
        current_q_sum = 0
        for i in range(self.n_agents):
            q_values = self.eval_net[i](obs[i])
            current_q = q_values.gather(1, actions[i].unsqueeze(1))
            current_q_sum += current_q
        with torch.no_grad():
            target_q_sum = 0
            for i in range(self.n_agents):
                next_q = self.target_net[i](next_obs[i])
                target_q_sum += next_q.max(1)[0].unsqueeze(1)
            targets = rewards.unsqueeze(1) + self.gamma * (1 - dones.unsqueeze(1)) * target_q_sum
        loss = torch.mean((current_q_sum - targets) ** 2)
        
        for optimizer in self.optimizers:
            optimizer.zero_grad()
        loss.backward()
        for optimizer in self.optimizers:
            optimizer.step()
        for i in range(self.n_agents):
            for param, target_param in zip(self.eval_net[i].parameters(), self.target_net[i].parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        
        return loss.item()
    def store_transition(self, state, action, reward, next_state, done):
        self.buffer.add(state, action, reward, next_state, done)
    def set_learn_flag(self, learn_flag=False):
        if learn_flag:
            self.epsilon = self.epsilon_start
        else:
            self.epsilon = self.epsilon_end
    def save_model(self, file):
        for i in range(self.n_agents):
            torch.save(self.eval_net[i].state_dict(), f'{file}/vdn_{i}.pkl')
    def load_model(self, file):
        for i in range(self.n_agents):
            self.eval_net[i].load_state_dict(torch.load(f'{file}/vdn_{i}.pkl'))
            self.target_net[i].load_state_dict(torch.load(f'{file}/vdn_{i}.pkl'))
