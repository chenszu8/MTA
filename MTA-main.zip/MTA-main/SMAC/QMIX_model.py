import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import torch.nn.functional as F
from collections import deque
import random

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class QNetwork(nn.Module):
    def __init__(self, obs_dim, action_dim):
        super(QNetwork, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, action_dim)
        )
    
    def forward(self, x):
        return self.net(x)

class MixingNetwork(nn.Module):
    def __init__(self, n_agents, state_dim, mixing_hidden=32):
        super(MixingNetwork, self).__init__()
        self.n_agents = n_agents
        self.state_dim = state_dim
        
        # Hyper networks
        self.hyper_w1 = nn.Linear(state_dim, n_agents * mixing_hidden)
        self.hyper_w2 = nn.Linear(state_dim, mixing_hidden * 1)
        
        # Bias networks
        self.hyper_b1 = nn.Linear(state_dim, mixing_hidden)
        self.hyper_b2 = nn.Sequential(
            nn.Linear(state_dim, mixing_hidden),
            nn.ReLU(),
            nn.Linear(mixing_hidden, 1)
        )

    def forward(self, q_values, states):
        # q_values: [batch_size, n_agents]
        # states: [batch_size, state_dim]
        batch_size = q_values.size(0)
        
        # First layer
        w1 = torch.abs(self.hyper_w1(states))  # [batch, n_agents * hidden]
        b1 = self.hyper_b1(states)              # [batch, hidden]
        w1 = w1.view(batch_size, self.n_agents, -1)  # [batch, n_agents, hidden]
        
        hidden = F.elu(torch.bmm(q_values.unsqueeze(1), w1).squeeze(1) + b1)  # [batch, hidden]
        
        # Second layer
        w2 = torch.abs(self.hyper_w2(states))  # [batch, hidden * 1]
        b2 = self.hyper_b2(states)              # [batch, 1]
        w2 = w2.view(batch_size, -1, 1)         # [batch, hidden, 1]
        
        q_total = torch.bmm(hidden.unsqueeze(1), w2).squeeze(1) + b2  # [batch, 1]
        return q_total.squeeze(-1)  # [batch]

class ReplayBuffer:
    def __init__(self, capacity, n_agents, obs_dim):
        self.buffer = deque(maxlen=capacity)
        self.n_agents = n_agents
        self.obs_dim = obs_dim

    def add(self, obs, actions, rewards, next_obs, dones, avail_actions):
        self.buffer.append((
            np.array(obs, dtype=np.float32),
            np.array(actions, dtype=np.int64),
            np.array(rewards, dtype=np.float32),
            np.array(next_obs, dtype=np.float32),
            np.array(dones, dtype=np.float32),
            np.array(avail_actions, dtype=np.int64)
        ))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        obs, actions, rewards, next_obs, dones, avail_actions = zip(*batch)
        return (
            torch.tensor(np.array(obs), dtype=torch.float32).to(device),          # [batch, n_agents, obs_dim]
            torch.tensor(np.array(actions), dtype=torch.long).to(device),         # [batch, n_agents]
            torch.tensor(np.array(rewards), dtype=torch.float32).to(device),     # [batch, n_agents, 1]
            torch.tensor(np.array(next_obs), dtype=torch.float32).to(device),    # [batch, n_agents, obs_dim]
            torch.tensor(np.array(dones), dtype=torch.float32).to(device),       # [batch, n_agents, 1]
            torch.tensor(np.array(avail_actions), dtype=torch.float32).to(device)# [batch, n_agents, action_dim]
        )

    def __len__(self):
        return len(self.buffer)

class QMIX:
    
    def __init__(self, n_agents, obs_dim, action_dim, 
                 buffer_size=4000, batch_size=64, lr=1e-5, gamma=0.99, tau=0.05):
        
        self.n_agents = n_agents
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        state_dim = n_agents * obs_dim
        self.gamma = gamma
        self.tau = tau
        self.batch_size = batch_size
        self.epsilon = 1.0
        self.eps_end = 0.05
        self.eps_decay = 0.995

        # Q networks
        self.q_net = QNetwork(obs_dim, action_dim).to(device)
        self.target_q_net = QNetwork(obs_dim, action_dim).to(device)
        self.target_q_net.load_state_dict(self.q_net.state_dict())

        # Mixing networks
        self.mixer = MixingNetwork(n_agents, state_dim).to(device)
        self.target_mixer = MixingNetwork(n_agents, state_dim).to(device)
        self.target_mixer.load_state_dict(self.mixer.state_dict())

        # Optimizer
        self.optimizer = optim.Adam([
            {'params': self.q_net.parameters()},
            {'params': self.mixer.parameters()}
        ], lr=lr)

        # Replay buffer
        self.buffer = ReplayBuffer(buffer_size, n_agents, obs_dim)

    def choose_action(self, obs, avail_actions):
        actions = []
        with torch.no_grad():
            for agent_idx in range(self.n_agents):
                if random.random() < self.epsilon:
                    # 随机选择可用动作
                    avail = np.where(avail_actions[agent_idx])[0]
                    action = int(np.random.choice(avail))
                else:
                    # 贪婪选择
                    obs_tensor = torch.FloatTensor(obs[agent_idx]).unsqueeze(0).to(device)
                    q_values = self.q_net(obs_tensor)  # [1, action_dim]
                    
                    # 修复维度问题：扩展掩码维度至 [1, action_dim]
                    avail_mask = torch.BoolTensor(avail_actions[agent_idx]).unsqueeze(0).to(device)
                    q_values = q_values.masked_fill(~avail_mask, -float('inf'))
                    
                    action = q_values.argmax(dim=-1).item()
                actions.append(action)
        self.update_epsilon()
        return actions

    def update(self):
        if len(self.buffer) < self.batch_size:
            return

        obs, actions, rewards, next_obs, dones, avail_actions = self.buffer.sample(self.batch_size)
        batch_size = obs.size(0)
        
        # 转换为全局状态
        state = obs.view(batch_size, -1)          # [batch, n_agents*obs_dim]
        next_state = next_obs.view(batch_size, -1)
        global_rewards = rewards.sum(dim=1)       # [batch, 1]
        global_dones = dones.any(dim=1).float()    # [batch, 1]

        # 计算当前Q值
        current_q_values = self.q_net(obs.view(-1, self.obs_dim)).view(batch_size, self.n_agents, -1)
        chosen_actions = actions.unsqueeze(-1)    # [batch, n_agents, 1]
        chosen_q_values = torch.gather(current_q_values, dim=2, index=chosen_actions).squeeze(-1)  # [batch, n_agents]
        q_total = self.mixer(chosen_q_values, state)  # [batch]

        # 计算目标Q值
        with torch.no_grad():
            target_q_values = self.target_q_net(next_obs.view(-1, self.obs_dim)).view(batch_size, self.n_agents, -1)  # [64,3,9]
            target_avail = avail_actions.view(batch_size, self.n_agents, self.action_dim).bool()  # 修正维度
            target_q_values[~target_avail] = -float('inf')  # 直接应用三维掩码
            target_max_q = target_q_values.max(dim=2)[0]    # [batch_size, n_agents]
            q_total_target = self.target_mixer(target_max_q, next_state)  # [batch]

        # 计算TD目标
        td_target = global_rewards.squeeze(-1) + self.gamma * (1 - global_dones.squeeze(-1)) * q_total_target

        # 计算损失
        loss = F.mse_loss(q_total, td_target.detach())

        # 反向传播
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # 软更新目标网络
        for param, target_param in zip(self.q_net.parameters(), self.target_q_net.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for param, target_param in zip(self.mixer.parameters(), self.target_mixer.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def update_epsilon(self):
        self.epsilon = max(self.eps_end, self.epsilon * self.eps_decay)

    def store_transition(self, obs, actions, rewards, next_obs, dones, avail_actions):
        self.buffer.add(obs, actions, rewards, next_obs, dones, avail_actions)