import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical
import torch.nn.functional as F

class PolicyNet(nn.Module):
    def __init__(self, obs_dim, action_dim, hidden_dim=128):
        super(PolicyNet, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
            nn.Softmax(dim=-1)
        )

    def forward(self, x):
        return self.fc(x)

class CriticNet(nn.Module):
    def __init__(self, state_dim, num_agents, action_dim, hidden_dim=128):
        super(CriticNet, self).__init__()
        input_dim = state_dim + num_agents * action_dim
        self.fc = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, state, actions):
        x = torch.cat([state, actions], dim=-1)
        return self.fc(x)

class COMA:
    def __init__(self, obs_dim, action_dim, num_agents, gamma=0.99, lr=1e-3):
        self.state_dim = obs_dim * num_agents
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        self.num_agents = num_agents
        self.gamma = gamma

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.policy_nets = [PolicyNet(obs_dim, action_dim).to(self.device) for _ in range(num_agents)]
        self.critic_net = CriticNet(self.state_dim, num_agents, action_dim).to(self.device)

        self.policy_optimizers = [optim.Adam(net.parameters(), lr=lr) for net in self.policy_nets]
        self.critic_optimizer = optim.Adam(self.critic_net.parameters(), lr=lr)

        self.action_space = torch.eye(action_dim).to(self.device)

    def choose_action(self, observations):
        actions = []
        log_probs = []
        for i in range(self.num_agents):
            obs = torch.FloatTensor(observations[i]).unsqueeze(0).to(self.device)
            probs = self.policy_nets[i](obs)
            dist = Categorical(probs)
            action = dist.sample()
            log_prob = dist.log_prob(action)
            actions.append(action.item())
            log_probs.append(log_prob.squeeze())
        return actions, log_probs

    def compute_advantages(self, states, joint_actions_onehot):
        batch_size = states.size(0)
        advantages = []

        current_Q = self.critic_net(states, joint_actions_onehot)

        for i in range(self.num_agents):
            others_actions = joint_actions_onehot.view(batch_size, self.num_agents, -1)
            others_actions = torch.cat([others_actions[:, :i], others_actions[:, i+1:]], dim=1)

            repeated_states = states.repeat_interleave(self.action_dim, dim=0)
            repeated_others = others_actions.repeat_interleave(self.action_dim, dim=0)
            agent_actions = self.action_space.repeat(batch_size, 1)

            new_joint_actions = torch.cat([
                agent_actions,
                repeated_others.view(-1, (self.num_agents - 1) * self.action_dim)
            ], dim=1)

            counterfactual_Q = self.critic_net(repeated_states, new_joint_actions)
            counterfactual_Q = counterfactual_Q.view(batch_size, self.action_dim)

            obs = states[:, i * self.obs_dim: (i + 1) * self.obs_dim]
            probs = self.policy_nets[i](obs).detach()

            expected_Q = (probs * counterfactual_Q).sum(dim=1, keepdim=True)
            advantage = current_Q - expected_Q
            advantages.append(advantage)

        return torch.cat(advantages, dim=1)

    def update(self, batch):
        states, joint_actions, rewards, next_states, dones = batch

        states = torch.FloatTensor(states).to(self.device)
        joint_actions = torch.LongTensor(joint_actions).to(self.device)
        rewards = torch.FloatTensor(rewards).unsqueeze(-1).to(self.device)
        next_states = torch.FloatTensor(next_states).to(self.device)
        dones = torch.FloatTensor(dones).unsqueeze(-1).to(self.device)

        batch_size = joint_actions.size(0)

        joint_actions_onehot = F.one_hot(joint_actions, num_classes=self.action_dim).float()
        joint_actions_onehot = joint_actions_onehot.view(batch_size, -1)

        # --- Critic update ---
        with torch.no_grad():
            next_joint_actions = []
            for i in range(self.num_agents):
                obs = next_states[:, i * self.obs_dim: (i + 1) * self.obs_dim]
                probs = self.policy_nets[i](obs)
                next_action = probs.argmax(dim=-1)
                one_hot = F.one_hot(next_action, num_classes=self.action_dim).float()
                next_joint_actions.append(one_hot)
            next_joint_actions = torch.cat(next_joint_actions, dim=-1)

            target_Q = rewards + self.gamma * self.critic_net(next_states, next_joint_actions) * (1 - dones)

        current_Q = self.critic_net(states, joint_actions_onehot)
        critic_loss = F.mse_loss(current_Q, target_Q)

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # --- Policy update ---
        advantages = self.compute_advantages(states, joint_actions_onehot).detach()
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        total_policy_loss = 0
        for i in range(self.num_agents):
            obs = states[:, i * self.obs_dim: (i + 1) * self.obs_dim]
            probs = self.policy_nets[i](obs)
            dist = Categorical(probs)

            action_idx = joint_actions[:, i]
            log_probs = dist.log_prob(action_idx)
            entropy = dist.entropy().mean()

            policy_loss = (-log_probs * advantages[:, i]).mean() - 0.01 * entropy
            total_policy_loss += policy_loss

        for opt in self.policy_optimizers:
            opt.zero_grad()
        total_policy_loss.backward()
        for opt in self.policy_optimizers:
            opt.step()
