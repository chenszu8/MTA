import numpy as np
import os
import random
from tqdm import tqdm
import time
from itertools import chain

from sysj import save_results_to_json
from DQN_model import DQN
from Mnt import Mnt
from COMA_model import COMA
from QMIX_model import QMIX
from VDN_model import VDN


def normalize_list(data):
    if not data:
        return []

    min_val = min(data)
    shifted = [x - min_val for x in data]
    total = sum(shifted)

    if total == 0:
        length = len(data)
        return [1 / length] * length

    normalized = [x / total for x in shifted]
    return normalized



max_trials = 2000
interval = 100

predict_mode = 0

#MTA
predict_num = 50
model_list = [62,75,59,81,17,33,77,16,47,88]

sub_num = 2
opp_num = 2
env_name = f'{sub_num}v{opp_num}'
agent_num = sub_num + opp_num
sub_agents = None
opp_agents = []
sub_net = 'QMIX'

sub_path = './expand_model/1v1/sub_model_30000.pkl'
opp_path = './single_models/2v2/opp_model_3_100000.pkl'

env = Mnt(sub_num=sub_num, opp_num=opp_num)
sub_obs_size = env.sub_obs_size
opp_obs_size = env.opp_obs_size
action_space = env.action_space

if sub_net == 'DQN':
    sub_agents = []
    for i in range(sub_num):
        sub_agents.append(DQN(i, 1, sub_obs_size, action_space, True))
        if sub_path:
            sub_agents[i].load_model(sub_path)
elif sub_net == 'COMA':
    sub_agents = COMA(sub_obs_size, action_space, sub_num)
elif sub_net == 'QMIX':
    sub_agents = QMIX(sub_num, sub_obs_size, action_space)
elif sub_net == 'VDN':
    sub_agents = VDN(sub_obs_size, action_space, sub_num, True)

for i in range(opp_num):
    opp_agents.append(DQN(i, 3, opp_obs_size, action_space, True, 8000))
    opp_agents[i].load_model(opp_path)



if predict_mode == 1:
    predict_model = []
    head = f'candidate_model/{env_name}/'
    for m in range(predict_num):
    #for i, m in enumerate(model_list):
        path = head + f'id_{m}.pkl'
        predict_model.append(DQN(m, 5, opp_obs_size, action_space))
        predict_model[m].load_model(path)

    predict_belief = [1] * predict_num
s_time = time.time()

success_rate = []

for k in range(int(max_trials / interval)):
    trial = 0
    suc = 0
    out = 0
    on_mine = 0
    conflict = 0
    be_capture = 0
    overdue = 0
    capture = 0

    with tqdm(total=interval, desc='Iteration %d' % k) as pbar:
        total_reward = 0
        while trial < interval:
            states = env.reset()
            done = False
            truncated = False
            actions = [0] * agent_num
            b_states, b_actions, b_rewards, b_next_states, b_dones = [], [], [], [], []
            while not done and not truncated:
                last_live = [0] * agent_num
                for agt in range(opp_num):
                    if env.check_live(agt):
                        last_live[agt] = 1
                        actions[agt] = opp_agents[agt].choose_action(states[sub_num + agt], True)[0]
                for agt in range(sub_num):
                    if env.check_live(agt):
                        last_live[agt] = 1
                        if sub_net == 'DQN':
                            action_list = sub_agents[agt].choose_action(states[agt], True)
                            if predict_mode:
                                agent_around = env.who_around(agt)
                                if predict_mode == 1:
                                    soft_belief = normalize_list(predict_belief)
                                    for i in agent_around:
                                        predict_action_list = [0] * action_space
                                        for m in range(predict_num):
                                            idx = (predict_model[m].choose_action(states[i], True))[0]
                                            predict_action_list[idx] += soft_belief[m]
                                            if idx == actions[i]:
                                                predict_belief[m] += 1
                                            else:
                                                predict_belief[m] -= 1

                                        predict_action = np.argmax(predict_action_list)
                                        action_list = [a for a in action_list if env.judge_move(agt, i, a, predict_action)]
                                elif predict_mode == 2:
                                    for i in agent_around:
                                        predict_action = actions[i]
                                        action_list = [a for a in action_list if env.judge_move(agt, i, a, predict_action)]

                            if len(action_list) == 0:
                                actions[agt] = random.choice(range(5))
                            else:
                                actions[agt] = action_list[0]
                        elif sub_net == 'COMA':
                            sub_obs = states[:sub_num]
                            sub_actions, _ = sub_agents.choose_action(states[:sub_num])
                            actions[:sub_num] = sub_actions
                        elif sub_net == 'QMIX' or sub_net == 'VDN':
                            actions[:sub_num] = sub_agents.choose_action(states[:sub_num])


                next_states, rewards, dones, done, truncated, info = env.step(actions)
                if sub_net == 'DQN':
                    for agt in range(sub_num):
                        if last_live[agt]:
                            sub_agents[agt].store_transition(states[agt], actions[agt], rewards[agt], next_states[agt], dones[agt])
                            sub_agents[agt].update()
                            
                elif sub_net == 'COMA':
                    b_states.append(list(chain.from_iterable(states[:sub_num])))
                    b_actions.append(actions[:sub_num])
                    b_rewards.append(sum(rewards[:sub_num]))
                    b_next_states.append(list(chain.from_iterable(next_states[:sub_num])))
                    b_dones.append(done)
                elif sub_net == 'QMIX' or sub_net == 'VDN':
                    sub_agents.store_transition(states[:sub_num], actions[:sub_num], rewards[:sub_num], next_states[:sub_num], dones[:sub_num])
                    for i in range(sub_num):
                        sub_agents.update()
                total_reward += rewards[:sub_num].sum()
                states = next_states
            if sub_net == 'COMA':
                sub_agents.update((b_states, b_actions, b_rewards, b_next_states, b_dones))
            trial += 1
            for agt in range(sub_num):
                if info is None:
                    exit(0)
                if info[agt] == 1:
                    suc += 1
                elif info[agt] == -1:
                    out += 1
                elif info[agt] == -2:
                    on_mine += 1
                elif info[agt] == -3:
                    conflict += 1
                elif info[agt] == -4:
                    be_capture += 1
                elif info[agt] == -5:
                    overdue += 1
            for agt in range(sub_num, agent_num):
                if info is not None:
                    capture += info[agt]

            assert be_capture == capture
            assert suc + out + on_mine + conflict + be_capture + overdue == trial * sub_num
            denom = sub_num * interval

            pbar.set_postfix({'trial': '%d' % (trial + interval * k), 'suc': '%.2f%%' % (suc / denom), 'out': '%.2f%%' % (out / denom), 'mine': '%.2f%%' % (on_mine / denom), 'capture_rate': '%.2f%%' % (capture / denom), 'overdue': '%.2f%%' % (overdue / denom), 'conflict': '%.2f%%' % (conflict / denom), 'reward': total_reward})
            pbar.update(1)
    success_rate.append(round(suc / (interval * sub_num), 3))
e_time = time.time()
mode = 'QMIX'
opp_type = '2V2'
datas = {
    f'consume_time_{mode}_{opp_type}':e_time - s_time,
    f'success_rate_{mode}_{opp_type}':success_rate,
}
save_log_path = './log/'
if not os.path.exists(save_log_path):
    os.makedirs(save_log_path)
json_save_path = save_log_path + 'online.json'
json_lock_path = json_save_path + '.lock'
save_results_to_json(datas, json_save_path, json_lock_path)





