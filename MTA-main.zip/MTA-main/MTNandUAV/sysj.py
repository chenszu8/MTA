import json
import csv

from filelock import FileLock

stats = {
    "start_time": None,
    "end_time": None,
    "total_time": 0.0,
    "success_rates": [],
    "total_tasks": 0,
    "failed_tasks": 0,
    "last_execution_time": None,
}

def save_results_to_json(results, file_path, lock_path):
    """
    将实验结果保存到文件中。

    :param results: 包含实验结果的字典
    :param file_path: 保存结果的文件路径
    :param lock_path: 文件锁的路径 文件锁指的是一个辅助文件 不需要实际存储数据 它的存在只是为了充当宇哥互斥信号
    比如 结果在result.json中 那文件锁路径可以为 result.json.lock
    :except json.load返回的通常是一个列表或者字典
    with lock 保证进入时获得锁，离开时释放锁
    """
    # 创建文件锁
    lock = FileLock(lock_path)

    # 确保写入过程是独占的
    with lock:
        try:
            try:
                with open(file_path, "r") as f:
                    existing_results = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                existing_results = {}

            # 遍历每个新结果，追加到已有列表中
            for key, value in results.items():
                if key in existing_results:
                    if isinstance(existing_results[key], list):
                        existing_results[key].append(value)
                    else:
                        print(f"警告：字段 {key} 已存在但不是 list，将被覆盖")
                        existing_results[key] = [value]
                else:
                    existing_results[key] = [value]

            # 写入文件，每个键值对换行，但数组保持一行
            json_str = "{\n"
            for i, (k, v) in enumerate(existing_results.items()):
                comma = "," if i < len(existing_results) - 1 else ""
                line = f'  "{k}": {json.dumps(v, separators=(",", ":"))}{comma}\n'
                json_str += line
            json_str += "}"

            with open(file_path, "w") as f:
                f.write(json_str)

        except Exception as e:
            print(f"保存结果时出错: {e}")

def save_results_to_csv(results, file_path, lock_path):

    from filelock import FileLock

    lock = FileLock(lock_path)

    # 确保写入过程是独占的
    with lock:
        # 检查文件是否已经存在
        file_exists = False
        try:
            with open(file_path, "r") as f:
                file_exists = True
        except FileNotFoundError:
            pass

        # 打开文件准备写入
        with open(file_path, "a", newline='') as f:
            writer = csv.writer(f)

            # 如果是首次写入，先写表头
            if not file_exists:
                header = ["Experiment", "Accuracy", "Loss"]
                writer.writerow(header)

            # 将新结果写入表中
            for experiment, metrics in results.items():
                row = [experiment, metrics.get("accuracy", ""), metrics.get("loss", "")]
                writer.writerow(row)
