import numpy as np
import time
import random
import copy
import torch
import os
from sysj import save_results_to_json
from tqdm import tqdm

from Mnt import Mnt
from DQN_model import DQN

random.seed(42)
q, w, e = 10, 6, 4
eta = 0.9
mode = 2

def ve_simulate(sub_num, opp_num, models):

    start_time = time.time()
    agent_num = sub_num + opp_num
    models_num = len(models)

    env = Mnt(sub_num=sub_num, opp_num=opp_num)
    sub_obs_size = env.sub_obs_size
    action_space = env.action_space

    env_num = 5
    env_paras = importance_sampling(env_num, mode)
    scenario_num = env_num * models_num

    scenarios = 0
    values = np.zeros((models_num, scenario_num))
    sims = np.zeros((models_num, models_num))

    sub_agent = DQN(0, 1, sub_obs_size, action_space)
    sub_agent.load_model('./expand_model/1v1/sub_model_30000.pkl')
    with tqdm(total=scenario_num) as pbar:
        for i in range(models_num):
            opp_agent = models[i]
            for ep in range(env_num):
                for m in range(models_num):
                    states = env.reset(env_paras[ep])
                    done = False
                    truncated = False
                    actions = [0] * agent_num
                    while not done and not truncated:
                        for agt in range(sub_num):
                            if env.check_live(agt):
                                action_list = sub_agent.choose_action(states[agt], True)
                                agent_around = env.who_around(agt)
                                for other in agent_around:
                                    predict_action = models[m].choose_action(states[other], True)[0]
                                    action_list = [a for a in action_list if env.judge_move(agt, other, action_list[a], predict_action)]
                                if len(action_list) == 0:
                                    actions[agt] = random.choice(range(action_space))
                                else:
                                    actions[agt] = action_list[0]
                        for agt in range(sub_num, agent_num):
                            if env.check_live(agt):
                                actions[agt] = opp_agent.choose_action(states[agt], True)[0]
                        next_states, rewards, dones, done, truncated, info = env.step(actions)
                        states = next_states
                        for agt in range(sub_num):
                            values[m][scenarios] += rewards[agt]
                scenarios += 1
                pbar.update(1)


    for i in range(models_num):
        for j in range(i + 1, models_num):
            eq_num = 0

            for k in range(scenario_num):
                if is_close_enough(values[i][k], values[j][k], eta):
                    eq_num += 1
            sims[i][j] = eq_num
            sims[j][i] = eq_num

    weight = [1] * models_num
    model_id = [i for i in range(models_num)]
    sim_test = copy.deepcopy(sims)

    while len(model_id) > q:

        two_max = np.unravel_index(np.argmax(sim_test), sim_test.shape)
        d = 0
        if values[model_id[two_max[0]]].sum() >= values[model_id[two_max[1]]].sum():
            d = 1
        weight[model_id[two_max[(d + 1) % 2]]] += weight[model_id[two_max[d]]]
        weight[model_id[two_max[d]]] = 0
        sim_test = np.delete(sim_test, two_max[d], axis=0)
        sim_test = np.delete(sim_test, two_max[d], axis=1)
        model_id.remove(model_id[two_max[d]])

    weight = [x for x in weight if x != 0]
    print(f'{q} scenrio model', model_id)
    print(f'{q} scenrio weight', weight)
    a = model_id[:]

    weight = [1] * models_num
    model_id = [i for i in range(models_num)]
    sim_test = copy.deepcopy(sims)
    while len(model_id) > w:
        two_max = np.unravel_index(np.argmax(sim_test), sim_test.shape)
        d = 0
        if values[model_id[two_max[0]]].sum() >= values[model_id[two_max[1]]].sum():
            d = 1
        weight[model_id[two_max[(d + 1) % 2]]] += weight[model_id[two_max[d]]]
        weight[model_id[two_max[d]]] = 0
        sim_test = np.delete(sim_test, two_max[d], axis=0)
        sim_test = np.delete(sim_test, two_max[d], axis=1)
        model_id.remove(model_id[two_max[d]])

    weight = [x for x in weight if x != 0]
    print(f'{w} scenrio model', model_id)
    print(f'{w} scenrio weight', weight)
    b = model_id[:]

    weight = [1] * models_num
    model_id = [i for i in range(models_num)]
    sim_test = copy.deepcopy(sims)
    while len(model_id) > e:
        two_max = np.unravel_index(np.argmax(sim_test), sim_test.shape)
        d = 0
        if values[model_id[two_max[0]]].sum() >= values[model_id[two_max[1]]].sum():
            d = 1
        weight[model_id[two_max[(d + 1) % 2]]] += weight[model_id[two_max[d]]]
        weight[model_id[two_max[d]]] = 0
        sim_test = np.delete(sim_test, two_max[d], axis=0)
        sim_test = np.delete(sim_test, two_max[d], axis=1)
        model_id.remove(model_id[two_max[d]])
    
    weight = [x for x in weight if x != 0]
    print(f'{e} scenrio model', model_id)
    print(f'{e} scenrio weight', weight)
    c = model_id[:]

    end_time = time.time()
    return a, b, c, end_time - start_time

def importance_sampling(num=5, mode=1):
    sub_num, opp_num = 1, 1
    agent_num = sub_num + opp_num
    env = Mnt(sub_num=sub_num, opp_num=opp_num)
    sub_obs_size = env.sub_obs_size
    action_space = env.action_space
    paras = []
    if mode == 1:
        for e in range(num):
            para = {'current': np.zeros((agent_num, 2)), 'bearing': [0] * agent_num, 'target': [0, 0], 'mine': []}
            env.reset()
            for agt in range(agent_num):
                para['current'][agt][0] = env.current[agt][0]
                para['current'][agt][1] = env.current[agt][1]
                para['bearing'][agt] = env.bearing[agt]
            para['target'][0] = env.target[0]
            para['target'][1] = env.target[1]
            for i in range(env.size):
                for j in range(env.size):
                    if env.mines_map[i][j] == 1:
                        para['mine'].append([i, j])
            paras.append(para)
    elif mode == 2:
        reinforce_model = DQN(0, 1, sub_obs_size, action_space)
        for e in range(num * 100):
            para = {'current': np.zeros((agent_num, 2)), 'bearing': [0] * agent_num, 'target': [0, 0], 'mine': []}
            env.reset()
            for agt in range(agent_num):
                para['current'][agt][0] = env.current[agt][0]
                para['current'][agt][1] = env.current[agt][1]
                para['bearing'][agt] = env.bearing[agt]
            para['target'][0] = env.target[0]
            para['target'][1] = env.target[1]
            for i in range(env.size):
                for j in range(env.size):
                    if env.mines_map[i][j] == 1:
                        para['mine'].append([i, j])
            paras.append(para)
        importance_list = []
        for para in paras:
            states = env.reset(para)
            discrepancy = 0
            for i in range(sub_num):
                discrepancy += reinforce_model.q_diff(states[i])
            importance_list.append(discrepancy)
        combined = list(zip(paras, importance_list))
        paras = [para for para, _ in sorted(combined, key=lambda x: x[1], reverse=True)[:num]]

    return paras


def is_close_enough(a, b, eta):
    if a * b < 0:
        return False
    min_val = min(a, b)
    max_val = max(a, b)
    return min_val / max_val >= eta

def be_condense(models):
    a, b, c = None, None, None
    max_sim_m_j = -1
    max_margin = float("-inf")
    states = states_sampling()
    batch_state = torch.FloatTensor(states)
    predict_actions_list = []
    for model in models:
        predict_actions = []
        for i in range(len(states)):
            state = batch_state[i]
            state = torch.unsqueeze(torch.FloatTensor(state), 0)
            action = model.choose_action(state, True)[0]
            predict_actions.append(action)
        predict_actions_list.append(predict_actions)
    model_k = []
    model_num = len(models)
    for n in range(10):
        sigma_k = compute_covp(model_num, model_k, predict_actions_list)
        for m in range(model_num):
            if m in model_k:
                continue
            tmp_model_k = []
            tmp_model_k.append(m)
            cov_p_k = compute_covp(model_num, tmp_model_k, predict_actions_list)
            tmp_prob = cov_p_k - sigma_k

            if tmp_prob > max_margin:
                max_margin = tmp_prob
                max_sim_m_j = m
        model_k.append(max_sim_m_j)
        if n == q - 1:
            a = model_k[:]
            print('BE: 10 scenrio model:', model_k)
        if n == w - 1:
            b = model_k[:]
            print('BE: 6 scenrio model:', model_k)
        if n == e - 1:
            c = model_k[:]
            print('BE: 4 scenrio model:', model_k)
        max_sim_m_j = -1
        max_margin = float("-inf")

    return a, b, c

def compute_covp(model_num, model_k, conflict_set):
    cov_p_m = 1
    cov_p_k = 0
    num_con_data = len(conflict_set[0])
    all_model = [m for m in range(model_num)]
    for m in all_model:
        for k in model_k:
            sim_p = compute_sim(conflict_set[k], conflict_set[m]) / num_con_data
            cov_p_m *= (1 - sim_p)
        cov_p_k += 1 - cov_p_m
        cov_p_m = 1
    return cov_p_k

def	compute_sim(predicted_action_k, predicted_action_m):
        num_con_data = len(predicted_action_k)
        sigma_k_j = 0.0
        for n in range(num_con_data):
            if predicted_action_k[n] == predicted_action_m[n]:
                sigma_k_j += 1
        return sigma_k_j


def states_sampling(num=1000):
    env = Mnt(sub_num = 1, opp_num = 1)
    obs = env.reset()
    states = []
    done = False
    truncated = False
    while len(states) < num:
        if done or truncated:
            obs = env.reset()
        for i in range(env.sub_num, env.agent_num):
            states.append(obs[i])
        actions = [0] * env.agent_num
        for i in range(env.sub_num):
            actions[i] = random.randint(0,env.action_space - 1)
        for i in range(env.sub_num, env.agent_num):
            actions[i] = random.randint(0,env.action_space - 1)
        
        obs, _, _, done, truncated, _ = env.step(actions)
    return states


def random_condense(num):
    a = random.sample(range(num), q)
    b = random.sample(range(num), w)
    c = random.sample(range(num), e)
    print('Random: 10 scenrio model:', a)
    print('Random: 6 scenrio model:', b)
    print('Random: 4 scenrio model:', c)
    return a, b, c



if __name__ == '__main__':
    models = []
    model_num = 50
    sub_num = 1
    opp_num = 1
    env_name = f'{sub_num}v{opp_num}'
    for m in range(model_num):
        file_head = f'candidate_model/{env_name}/'
        models.append(DQN(m, 5, 9, 5))
        opp_path = file_head + f'id_{m}.pkl'
        models[m].load_model(opp_path)

    a1, b1, c1, times = ve_simulate(sub_num, opp_num, models)
    a2, b2, c2 = be_condense(models)
    a3, b3, c3 = random_condense(model_num)

    datas = {
        've_consume_time': times,
        f"ve{model_num}_result_{eta}_{q}_{'IS' if mode == 2 else 'random'}": a1,
        f"ve{model_num}_result_{eta}_{w}_{'IS' if mode == 2 else 'random'}": b1,
        f"ve{model_num}_result_{eta}_{e}_{'IS' if mode == 2 else 'random'}": c1,
        f'be{model_num}_result_{q}': a2,
        f'be{model_num}_result_{w}': b2,
        f'be{model_num}_result_{e}': c2,
        f'random{model_num}_result_{q}': a3,
        f'random{model_num}_result_{w}': b3,
        f'random{model_num}_result_{e}': c3,
    }
    
    save_log_path = './log/'
    if not os.path.exists(save_log_path):
        os.makedirs(save_log_path)
    json_save_path = save_log_path + 'condense.json'
    json_lock_path = json_save_path + '.lock'

    save_results_to_json(datas, json_save_path, json_lock_path)




